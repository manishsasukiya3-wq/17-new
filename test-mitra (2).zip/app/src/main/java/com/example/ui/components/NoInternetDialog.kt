package com.example.ui.components

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.MitraBgLight
import com.example.ui.theme.MitraError
import com.example.ui.theme.MitraErrorLight
import com.example.ui.theme.MitraNavyPrimary
import com.example.ui.theme.MitraTextPrimary
import com.example.ui.theme.MitraTextSecondary

@Composable
fun NoInternetDialog(
    onRetry: () -> Unit
) {
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = { /* Non-dismissible: Internet is mandatory */ },
        properties = DialogProperties(
            dismissOnBackPress = false,
            dismissOnClickOutside = false
        ),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("no_internet_dialog"),
        shape = RoundedCornerShape(24.dp),
        containerColor = Color.White,
        title = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Surface(
                    modifier = Modifier.size(76.dp),
                    shape = CircleShape,
                    color = MitraErrorLight
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.WifiOff,
                            contentDescription = "No Internet Icon",
                            tint = MitraError,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "No Internet Connection",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MitraTextPrimary,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "Internet Connection Required",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MitraNavyPrimary,
                    textAlign = TextAlign.Center
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MitraBgLight,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "An active internet connection (Mobile Data or Wi-Fi) is required to use TEST MITRA.",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = MitraTextPrimary,
                            lineHeight = 19.sp,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "Please check your network connection and tap 'Retry'.",
                            fontSize = 12.sp,
                            color = MitraTextSecondary,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        },
        confirmButton = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MitraPrimaryButton(
                    text = "Retry",
                    onClick = onRetry,
                    icon = Icons.Default.Refresh,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "no_internet_retry_button"
                )
                MitraOutlinedButton(
                    text = "Open Settings",
                    onClick = {
                        try {
                            val intent = Intent(Settings.ACTION_WIRELESS_SETTINGS).apply {
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            }
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            try {
                                val intent = Intent(Settings.ACTION_WIFI_SETTINGS).apply {
                                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                }
                                context.startActivity(intent)
                            } catch (_: Exception) {}
                        }
                    },
                    icon = Icons.Default.Settings,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "open_internet_settings_button"
                )
            }
        },
        dismissButton = null
    )
}
